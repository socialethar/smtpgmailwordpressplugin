<?php
/*
Plugin Name: Ethar SMTP for Gmail
Description: An SMTP plugin for configuring Gmail SMTP settings. Last tested with WordPress version 6.5.4 on June 6, 2024. No security vulnerabilities. Nice plugin.
Version: 1.1.0
Author: Mohammed Ethar, socialethar@gmail.com, Ethar-IT
Author URI: http://developerethar.com
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/
function start_session_ethar() {  /*session start*/
	   if (session_status() == PHP_SESSION_NONE) {
	       session_start();
	   }
}
add_action('init', 'start_session_ethar');

use PHPMailer\PHPMailer\PHPMailer;

// Activation hook
register_activation_hook(__FILE__, 'custom_gmail_smtp_activate');

function custom_gmail_smtp_activate() {
    global $wpdb;

    // Define table name
    $table_nameethar = $wpdb->prefix . 'ethar_gmail_smtp';

    // SQL statement to create table
    $sql = "CREATE TABLE IF NOT EXISTS $table_nameethar (
        id INT AUTO_INCREMENT PRIMARY KEY,
        host VARCHAR(255) NOT NULL,
        smtp_auth BOOLEAN NOT NULL,
        port INT NOT NULL,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        smtp_secure VARCHAR(10) NOT NULL,
        from_email VARCHAR(255) NOT NULL,
        from_name VARCHAR(255) NOT NULL,
        license_code VARCHAR(255) NOT NULL
    )";

    // Execute SQL query
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
};

// Deactivation hook
register_deactivation_hook(__FILE__, 'custom_gmail_smtp_deactivate');

function custom_gmail_smtp_deactivate() {
    global $wpdb;

    // Define table name
    $table_nameethar = $wpdb->prefix . 'ethar_gmail_smtp';

    // SQL statement to drop table
    $sql = "DROP TABLE IF EXISTS $table_nameethar";

    // Execute SQL query
    $wpdb->query($sql);
};




function configure_gmail_smtp(PHPMailer $phpmailer) { //smtp configuration
    global $wpdb;

    // Define table name
    $table_nameethar = $wpdb->prefix . 'ethar_gmail_smtp';

    // Fetch last row from the table
    $last_dataethar = $wpdb->get_row("SELECT * FROM $table_nameethar ORDER BY id DESC LIMIT 1");

    // Validate fetched data
    if ($last_dataethar) {
        // Use fetched values to configure SMTP settings
        $phpmailer->isSMTP();
        $phpmailer->Host = $last_dataethar->host;
        $phpmailer->SMTPAuth = $last_dataethar->smtp_auth ? 'true' : 'false';
        $phpmailer->Port = $last_dataethar->port;
        $phpmailer->Username = $last_dataethar->username;
        $phpmailer->Password = $last_dataethar->password;
        $phpmailer->SMTPSecure = $last_dataethar->smtp_secure;
        $phpmailer->From = $last_dataethar->from_email;
        $phpmailer->FromName = $last_dataethar->from_name;
    } else {
        // Use default or blank values
        $phpmailer->isSMTP();
        $phpmailer->Host = 'smtp.gmail.com';
        $phpmailer->SMTPAuth = true;
        $phpmailer->Port = 587; // For TLS
        $phpmailer->Username = '';
        $phpmailer->Password = '';
        $phpmailer->SMTPSecure = 'tls';
        $phpmailer->From = ''; //
        $phpmailer->FromName = 'Ethar';
    }
};
add_action('phpmailer_init', 'configure_gmail_smtp');






// theme support for supporting menu
function my_theme_setup() {
    add_theme_support('menus');
};
add_action('after_setup_theme', 'my_theme_setup');
//add theme support complete


/*Make menu and submenu using settings api*/
add_action('admin_menu', function() {  
    add_menu_page(
        'Gmail SMTP by Ethar',
        'Gmail smtp',
        'manage_options',
        'ethargmailsmtpid',
        'gmailsmtpcallback',
        'dashicons-email',
        10
    );

    add_submenu_page(
        'ethargmailsmtpid',
        'Configure smtp',
        'Configure',
        'manage_options',
        'ethargmailsmtpconid',
        'gmailsmtpconfigureCallback'
    );


    add_submenu_page(
        'ethargmailsmtpid',
        'Test',
        'Test',
        'manage_options',
        'ethargmailsmtptestid',
        'gmailsmtptestCallback'
    );


    add_submenu_page(
        'ethargmailsmtpid',
        'License',
        'License',
        'manage_options',
        'ethargmailsmtplicenseid',
        'gmailsmtplicenseCallback'
    );
});


/*menu callback function*/
function gmailsmtpcallback() {
	$configure_urletharsmtp = menu_page_url('ethargmailsmtpconid', false);
?>
	<h1>Gmail SMTP</h1>
	<p>This is an SMTP plugin only for Gmail. This plugin is lightweight and easy to use. It is totally free. Enjoy!</p>
	<p style="color: #CCCCCC;">Powered by Ethar-IT, socialethar@gmail.com</p>
	<a class="btnethar" href="<?php echo esc_url($configure_urletharsmtp); ?>">Configure</a>
	<style>
		.btnethar {
	        display: inline-block;
	        padding: 10px 20px;
	        font-size: 16px;
	        font-weight: bold;
	        color: white;
	        background-color: #0073aa; /* WordPress admin blue color */
	        border: none;
	        border-radius: 5px;
	        text-decoration: none;
	        text-align: center;
	        transition: background-color 0.3s, transform 0.3s;
	    }
	    .btnethar:hover {
	        background-color: #005177;
	        transform: scale(1.05);
	    }
	    .btnethar:active {
	        background-color: #003d5c;
	        transform: scale(0.98);
	    }
	</style>
<?php
};

/*Submenu callback function*/
function gmailsmtpconfigureCallback() {

    $ethar_csrf = "";
	function generate_csrf_token_ethar() {
	    if (empty($_SESSION['csrf_tokenethar'])) {
	    	$ethar_csrf = bin2hex(random_bytes(32));
	        $_SESSION['csrf_tokenethar'] = $ethar_csrf; // Generate csrf token
	    };

	    if (!isset($_SESSION['csrf_tokenethar'])) {
		    $_SESSION['csrf_tokenethar'] = "";
	    	$ethar_csrf = bin2hex(random_bytes(32));
	        $_SESSION['csrf_tokenethar'] = $ethar_csrf; // Generate csrf token
	    };
	}
	generate_csrf_token_ethar();


	global $wpdb;
    $table_nameethar = $wpdb->prefix . 'ethar_gmail_smtp'; /*table name*/

    // Process form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        /*csrf token validation*/
    	if (isset($_POST['etharcsrftoken'])) {
    		$formCsrfData_ethar = $_POST['etharcsrftoken'];
    		if ($_SESSION['csrf_tokenethar']) {
    			if ($formCsrfData_ethar === $_SESSION['csrf_tokenethar']) {
	    			$ethar_csrf = bin2hex(random_bytes(32));
	    			$_SESSION['csrf_tokenethar'] = $ethar_csrf;
	    		}else {
	    			echo '<div class="error"><p>csrf token error</p></div>';
	    			exit;
	    		};
    		}else {
    			echo '<div class="error"><p>csrf token error</p></div>';
    			exit;
    		};
    	}else {
    		echo '<div class="error"><p>csrf token error</p></div>';
    		exit;
    	};

        // Validate and sanitize input
        $host = isset($_POST['hostethar']) ? sanitize_text_field($_POST['hostethar']) : '';
        $smtp_auth = isset($_POST['smtp_auth']) ? 1 : 0;
        $port = isset($_POST['portethar']) ? intval($_POST['portethar']) : 0;
        $username = isset($_POST['usernameethar']) ? sanitize_text_field($_POST['usernameethar']) : '';
        $password = isset($_POST['passwordethar']) ? sanitize_text_field($_POST['passwordethar']) : '';
        $smtp_secure = isset($_POST['smtp_secure']) ? sanitize_text_field($_POST['smtp_secure']) : '';
        $from_email = isset($_POST['from_emailethar']) ? sanitize_email($_POST['from_emailethar']) : '';
        $from_name = isset($_POST['from_nameethar']) ? sanitize_text_field($_POST['from_nameethar']) : '';
        $license_code = isset($_POST['license_codeethar']) ? sanitize_text_field($_POST['license_codeethar']) : '';

        // Check if any field is empty
        if (empty($host) || empty($port) || empty($username) || empty($password) || empty($smtp_secure) || empty($from_email) || empty($from_name) || empty($license_code)) {
            echo '<div class="error"><p>Please fill in all required fields.</p></div>';
        } else {
            // Check if table already has any row
            $row = $wpdb->get_row("SELECT * FROM $table_nameethar ORDER BY id DESC LIMIT 1");

            if ($row) {
                // Update the last row
                $wpdb->update(
                    $table_nameethar,
                    [
                        'host' => $host,
                        'smtp_auth' => $smtp_auth,
                        'port' => $port,
                        'username' => $username,
                        'password' => $password,
                        'smtp_secure' => $smtp_secure,
                        'from_email' => $from_email,
                        'from_name' => $from_name,
                        'license_code' => $license_code
                    ],
                    ['id' => $row->id]
                );
                echo '<div class="updated"><p>Settings updated successfully.</p></div>';
            } else {
                // Insert a new row
                $wpdb->insert(
                    $table_nameethar,
                    [
                        'host' => $host,
                        'smtp_auth' => $smtp_auth,
                        'port' => $port,
                        'username' => $username,
                        'password' => $password,
                        'smtp_secure' => $smtp_secure,
                        'from_email' => $from_email,
                        'from_name' => $from_name,
                        'license_code' => $license_code
                    ]
                );
                echo '<div class="updated"><p>Settings saved successfully.</p></div>';
            }
        }
    };



    // Fetch the last row from the table
    $row = $wpdb->get_row("SELECT * FROM $table_nameethar ORDER BY id DESC LIMIT 1");

    // Set form field values
    $host = $row ? $row->host : '';
    $smtp_auth = $row ? $row->smtp_auth : 0;
    $port = $row ? $row->port : '';
    $username = $row ? $row->username : '';
    $password = $row ? $row->password : '';
    $smtp_secure = $row ? $row->smtp_secure : '';
    $from_email = $row ? $row->from_email : '';
    $from_name = $row ? $row->from_name : '';
    $license_code = $row ? $row->license_code : '';

?>
	<h1>Configuration</h1>
	<div class="form-containerethar">
	    <form action="" method="post">
	        <div class="form-fieldethar">
	            <label for="hostethar">Host</label>
	            <input type="text" id="hostethar" name="hostethar" value="<?php echo esc_attr($host); ?>" required autocomplete="off" placeholder="smtp.gmail.com">
	        </div>
	        <div class="form-fieldethar">
	            <label for="smtp_auth">SMTP Auth</label>
	            <input type="checkbox" id="smtp_auth" name="smtp_auth" <?php checked($smtp_auth, 1); ?> title="do checked for true">
	        </div>
	        <div class="form-fieldethar">
	            <label for="portethar">Port</label>
	            <input type="number" id="portethar" name="portethar" value="<?php echo esc_attr($port); ?>" required autocomplete="off" placeholder="587 / 465........">
	        </div>
	        <div class="form-fieldethar">
	            <label for="usernameethar">Username</label>
	            <input type="text" id="usernameethar" name="usernameethar" value="<?php echo esc_attr($username); ?>" required autocomplete="off" placeholder="example@gmail.com">
	        </div>
	        <div class="form-fieldethar">
	            <label for="passwordethar">Password</label>
	            <input type="password" id="passwordethar" name="passwordethar" value="<?php echo esc_attr($password); ?>" required autocomplete="off">
	        </div>
	        <div class="form-fieldethar">
	            <label for="smtp_secure">SMTP Secure</label>
	            <input type="text" placeholder="tls / ssl......." id="smtp_secure" name="smtp_secure" value="<?php echo esc_attr($smtp_secure); ?>" required autocomplete="off">
	        </div>
	        <div class="form-fieldethar">
	            <label for="from_emailethar">From Email</label>
	            <input type="email" id="from_emailethar" name="from_emailethar" value="<?php echo esc_attr($from_email); ?>" required autocomplete="off" placeholder="example@gmail.com">
	        </div>
	        <div class="form-fieldethar">
	            <label for="from_nameethar">From Name</label>
	            <input type="text" id="from_nameethar" name="from_nameethar" value="<?php echo esc_attr($from_name); ?>" required autocomplete="off" placeholder="Your company name">
	        </div>
	        <div class="form-fieldethar">
	            <label for="license_codeethar">License Code</label>
	            <input type="text" id="license_codeethar" value="123456789smtpEtharGmail" readonly name="license_codeethar" required autocomplete="off">
	            <input type="hidden" value="<?php echo esc_attr($_SESSION['csrf_tokenethar']); ?>" name="etharcsrftoken">
	        </div>
	        <div class="form-fieldethar">
	            <input type="submit" value="Save Settings">
	        </div>
	    </form>
	</div>

	<style>
		/* Container for the form */
		.form-containerethar {
		    max-width: 600px;
		    margin: 0 auto;
		    padding: 20px;
		    background-color: #f9f9f9;
		    border: 1px solid #e1e1e1;
		    border-radius: 8px;
		    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
		}

		/* Form field */
		.form-fieldethar {
		    margin-bottom: 15px;
		}

		/* Label */
		.form-fieldethar label {
		    display: block;
		    margin-bottom: 5px;
		    font-weight: bold;
		    color: #333;
		}

		/* Input */
		.form-fieldethar input[type="text"],
		.form-fieldethar input[type="number"],
		.form-fieldethar input[type="password"],
		.form-fieldethar input[type="email"] {
		    width: 100%;
		    padding: 10px;
		    font-size: 16px;
		    border: 1px solid #ccc;
		    border-radius: 4px;
		    box-sizing: border-box;
		    transition: border-color 0.3s;
		}

		/* Input focus */
		.form-fieldethar input[type="text"]:focus,
		.form-fieldethar input[type="number"]:focus,
		.form-fieldethar input[type="password"]:focus,
		.form-fieldethar input[type="email"]:focus {
		    border-color: #0073aa;
		    outline: none;
		}

		/* Checkbox */
		.form-fieldethar input[type="checkbox"] {
		    margin-right: 10px;
		}

		/* Submit button */
		.form-fieldethar input[type="submit"] {
		    width: 100%;
		    padding: 10px;
		    font-size: 16px;
		    font-weight: bold;
		    color: white;
		    background-color: #0073aa;
		    border: none;
		    border-radius: 4px;
		    cursor: pointer;
		    transition: background-color 0.3s;
		}

		.form-fieldethar input[type="submit"]:hover {
		    background-color: #005177;
		}
	</style>

<?php
};

/*submenu callback function*/
function gmailsmtptestCallback() {
	// Check if the form is submitted and the email field is not empty
	if (isset($_POST['emailsmtpethar'])) {

		global $wpdb;
        $table_nameethar = $wpdb->prefix . 'ethar_gmail_smtp';   /*table name*/
	    // Fetch the last row from the database table
	    $last_rowethar = $wpdb->get_row("SELECT * FROM $table_nameethar ORDER BY id DESC LIMIT 1"); /*query*/

	    // Check if the last row exists
	    if ($last_rowethar) {
	        $headers = 'From: ' . $last_rowethar->from_email;

	        // Send the email
	        $to = $_POST['emailsmtpethar']; // Replace with your email address
	        $subject = 'Test Email from WordPress';
	        $message = 'This is a test email to check Gmail SMTP configuration.';
	        
	        // Send the email
	        if (wp_mail($to, $subject, $message, $headers)) {  /*checking mail*/
	            // Email sent successfully
	            echo '<div style="padding: 10px;" class="updated">Email sent successfully.</div>';
	        } else {
	            // Failed to send email
	            echo '<div style="padding: 10px;" class="error">Failed to send email.</div>';
	        }
	    } else {
	        // No data found in the database
	        echo '<div style="padding: 10px;" class="error">No data found in the database.</div>';
	    }
	};

?>
	<h1>Test</h1>
	<form id="email-formethar" action="" method="post">
	    <div class="form-groupethar">
	        <label for="emailsmtpethar">Email</label>
	        <input type="email" id="emailsmtpethar" name="emailsmtpethar" placeholder="Enter your email" required>
	    </div>
	    <div class="form-groupethar">
	        <button type="submit" class="btn-sendethar" value="smtptestsubmit">Send</button>
	    </div>
	</form>

	<style>
	    #email-formethar {
	        max-width: 400px;
	        margin: 0 auto;
	        padding: 20px;
	        background-color: #f9f9f9;
	        border: 1px solid #ddd;
	        border-radius: 5px;
	    }

	    .form-groupethar {
	        margin-bottom: 20px;
	    }

	    #email-formethar label {
	        display: block;
	        font-weight: bold;
	        margin-bottom: 5px;
	    }

	    #email-formethar input[type="email"] {
	        width: 100%;
	        padding: 10px;
	        font-size: 16px;
	        border: 1px solid #ccc;
	        border-radius: 4px;
	        box-sizing: border-box;
	    }

	    .btn-sendethar {
	        padding: 10px 20px;
	        font-size: 16px;
	        font-weight: bold;
	        color: #fff;
	        background-color: #007bff;
	        border: none;
	        border-radius: 4px;
	        cursor: pointer;
	        transition: background-color 0.3s;
	    }

	    .btn-sendethar:hover {
	        background-color: #0056b3;
	    }
	</style>
<?php
};

/*submenu callback function*/
function gmailsmtplicenseCallback() {
	global $wpdb;
    $table_nameethar = $wpdb->prefix . 'ethar_gmail_smtp';
	// Fetch the last row from the database table
	$licensesmtpEthar = $wpdb->get_row("SELECT * FROM $table_nameethar ORDER BY id DESC LIMIT 1");
?>
	<h1 style="color: #3498db;;">License</h1>
	<p style="font-size: 15px;">It's an open-source WordPress plugin. It is developed for Gmail SMTP configuration in WordPress. This plugin is lightweight and very easy to use. This plugin is under the GPL license. Company: Ethar-IT. Developed by Mohammed Ethar. Bangladesh.</p>
	<p>Development Environment::  php version-8.2.12 in xampp. 10.4.32-MariaDB. mysqlnd 8.2.12 . Apache/2.4.58 (Win64) OpenSSL/3.1.3 PHP/8.2.12 . wordpress version: 6.5.4</p>
<?php
    if ($licensesmtpEthar) {
    	if($licensesmtpEthar->license_code === "123456789smtpEtharGmail") { /*license checking*/
    		echo "<p style='font-size: 30px; color: green;'>License ok</p>";
    	};
    };
};

//End, Mohammed Ethar, socialethar@gmail.com, Ethar-IT
?>