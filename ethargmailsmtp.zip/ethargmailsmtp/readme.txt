=== Ethar SMTP for Gmail ===
Contributors: mdethar
Donate link: http://developerethar.com
Tags: gmail, smtp, email, mail, smtp configuration, Gmail configuration, Email configuration, Wordpress
Requires at least: 4.6
Tested up to: 6.5.4
Requires PHP: 7.4 or higher
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
An SMTP plugin for configuring the Gmail SMTP settings. Released on 06 June 2024. Ethar-IT, Developed by Mohammed Ethar, socialethar@gmail.com. Bangladesh

== Installation ==
1. Upload `gmail-smtp-by-ethar` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin by going to the Gmail SMTP configure page.

== Screenshots ==
1. Screenshot description 1.
2. Screenshot description 2.
3. Screenshot description 3.
4. Screenshot description 4.
5. Screenshot description 5.

== Changelog ==
= 1.1.0 =
* Initial release with improved security features.